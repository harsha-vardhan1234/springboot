package com.request.Body;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BodyApplicationTests {

	@Test
	void contextLoads() {
	}

}
